package simpledb.buffer;

import simpledb.file.Block;

public class MyBuffeTester {

	public static void main(String[] args) 
	{
		/*
		int numBuffers = 10 ;
		int blkNum =100 ; 
		String fileName ="dummy.txt" ; 
		Block testBlockObj = new Block(fileName, blkNum);
		BufferMgr buffMgrObj = new BufferMgr(numBuffers);
		buffMgrObj.pin(testBlockObj);
		if(buffMgrObj.containsMapping(testBlockObj))
		{
			System.out.println("There is  a mapping between block #" + testBlockObj.number()  + " , and this buffer #" + buffMgrObj.getMapping(testBlockObj));
		}
		*/

	}

}
